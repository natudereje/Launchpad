x = 7000 * 40
print (x)